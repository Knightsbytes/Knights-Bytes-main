list = [
    "announceAdvancements",
    "commandBlockOutput",
    "disableElytraMovementCheck",
    "disableRaids",
    "doDaylightCycle",
    "doEntityDrops",
    "doFireTick",
    "doImmediateRespawn",
    "doInsomnia",
    "doLimitedCrafting",
    "doMobLoot",
    "doMobSpawning",
    "doPatrolSpawning",
    "doTileDrops",
    "doTraderSpawning",
    "doWeatherCycle",
    "drowningDamage",
    "fallDamage",
    "fireDamage",
    "forgiveDeadPlayers",
    "freezeDamage",
    "keepInventory",
    "logAdminCommands",
    "mobGriefing",
    "naturalRegeneration",
    "reducedDebugInfo",
    "sendCommandFeedback",
    "showDeathMessages",
    "spectatorsGenerateChunks",
    "universalAnger"
]

for i in list:
    print(f"scoreboard objectives add {i} dummy")

print("\n")

for i in list:
    print(f"execute store success score #global {i} run gamerule {i}")
print("\n")

for i in list:
    print("tellraw @s [{\"text\":\"" + i + " is currently set to \",\"color\":\"green\"},{score:{\"name\":\"#global\",\"objective\":\"" + i + "\"}}]")
