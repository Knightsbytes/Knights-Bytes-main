import pygame
import math
import random
import time

pygame.init()
win = pygame.display.set_mode((500, 500))
clock = pygame.time.Clock()
pygame.display.set_icon(pygame.image.load("spr/player.png"))

global gamestate
gamestate = "startmenu"


def load_spritesheet_images(spritesheet_path, sprite_width, sprite_height, frames_per_row, total_frames=None,
                            scale=None):
    try:
        sheet = pygame.image.load(spritesheet_path).convert_alpha()
    except pygame.error as e:
        print(f"Unable to load spritesheet: {spritesheet_path}")
        raise SystemExit(e)

    images = []
    sheet_width = sheet.get_width()
    sheet_height = sheet.get_height()

    max_cols = sheet_width // sprite_width
    max_rows = sheet_height // sprite_height
    max_frames = max_cols * max_rows

    if total_frames is None:
        total_frames = max_frames
    else:
        total_frames = min(total_frames, max_frames)

    frame_count = 0
    row = 0
    col = 0

    while frame_count < total_frames:

        x = col * sprite_width
        y = row * sprite_height

        if x + sprite_width > sheet_width or y + sprite_height > sheet_height:
            break

        image = pygame.Surface((sprite_width, sprite_height), pygame.SRCALPHA)
        image.blit(sheet, (0, 0), (x, y, sprite_width, sprite_height))

        if scale:
            image = pygame.transform.scale(image, scale)

        images.append(image)
        frame_count += 1

        col += 1
        if col >= frames_per_row:
            col = 0
            row += 1

    return images


def vector_move(x1, y1, x2, y2, speed):
    dx = x2 - x1
    dy = y2 - y1
    length = (dx ** 2 + dy ** 2) ** 0.5
    if length == 0:
        return 0, 0

    if dx != 0:
        m = dy / dx
    else:
        m = float('inf')

    dx = dx / length * speed
    dy = dy / length * speed
    return dx, dy, m


def find_angle_with_m(dx, dy):
    return math.degrees(math.atan2(dy, -dx))


def generate_hitbox(image, x, y):
    if image.get_flags() & pygame.SRCALPHA == 0:
        temp = pygame.Surface(image.get_size(), pygame.SRCALPHA)
        temp.blit(image, (0, 0))
        image = temp

    mask = pygame.mask.from_surface(image)

    if mask.count() == 0:
        rect = image.get_rect()
        rect.x = x
        rect.y = y
        return rect

    bounds = mask.get_bounding_rects()
    if not bounds:
        rect = image.get_rect()
        rect.x = x
        rect.y = y
        return rect

    hitbox = bounds[0].unionall(bounds[1:]) if len(bounds) > 1 else bounds[0]

    hitbox.x += x
    hitbox.y += y

    return hitbox


class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y, vel, hp):
        super().__init__()
        self.x = x
        self.y = y
        self.vel = vel
        self.hp = player.level + hp
        self.spr = pygame.image.load("spr/enemy.png")
        self.movement_type = 0
        self.spr = pygame.transform.scale(self.spr, (28, 60))
        self.speed = (player.level / 4) + 2
        self.hitbox = pygame.Rect(0, 0, 28, 60)
        self.screen_x = 0
        self.screen_y = 0

        self.onfire = False
        self.fireticks = 0
        self.firetickanimframe = 0
        self.firedamage = 0

        self.fireframes = load_spritesheet_images("spr/effects/fire.png", 32,32, 6, 11)
        
        for i in range(len(self.fireframes)):
            self.fireframes[i] = pygame.transform.scale(self.fireframes[i], (64,64))
        
        self.animation_frame = 0
        self.animation_frame_update = 0
        self.explosion = [pygame.image.load("spr/effects/explosion/01.png"),
                          pygame.image.load("spr/effects/explosion/02.png"),
                          pygame.image.load("spr/effects/explosion/03.png"),
                          pygame.image.load("spr/effects/explosion/04.png"),
                          pygame.image.load("spr/effects/explosion/05.png"),
                          pygame.image.load("spr/effects/explosion/06.png"),
                          pygame.image.load("spr/effects/explosion/07.png"),
                          pygame.image.load("spr/effects/explosion/08.png")]

        for i in range(len(self.explosion)):
            self.explosion[i] = pygame.transform.scale(self.explosion[i], (128, 128))

    def move_towards_player(self):
        if self.hp > 0:
            self.movement_type = random.randrange(1, 10)
            self.dx, self.dy, self.m = vector_move(self.x, self.y, player.world_x, player.world_y, self.vel)
            self.x += self.dx * self.speed
            self.y += self.dy * self.speed

    def draw(self):
        self.screen_x = self.x - (player.world_x - 250)
        self.screen_y = self.y - (player.world_y - 250)



        if self.hp > 0:
            win.blit(self.spr, (self.screen_x, self.screen_y))
            self.hitbox = generate_hitbox(self.spr, self.screen_x, self.screen_y)

            if self.onfire:

                if self.firetickanimframe < len(self.fireframes):
                    self.firetickanimframe += 1
                    self.fireticks -= 1
                    #win.blit(self.fireframes[self.firetickanimframe], (self.screen_x - 7, self.screen_y))

                if self.firetickanimframe == len(self.fireframes):
                    self.firetickanimframe = 0

                win.blit(self.fireframes[self.firetickanimframe], (self.screen_x - 7, self.screen_y))
            #if self.fireticks == 0:
            #    self.onfire = False

    def deathanimation(self, x, y):
        self.animation_frame_update += 0.5
        player.xp += 0.5
        if self.animation_frame_update >= 1:
            self.animation_frame_update = 0
            if self.animation_frame < 7:
                self.animation_frame += 1

        if self.animation_frame < 8:
            win.blit(self.explosion[self.animation_frame], (x - 50, y - 34))

    def update(self):
        if self.hp > 0:
            self.move_towards_player()
            self.draw()
        else:

            self.deathanimation(self.screen_x, self.screen_y)
            self.hitbox = generate_hitbox(self.spr, 10000, 10000)

    def take_damage(self, damage):
        self.hp -= damage

        if self.hp <= 0:
            self.animation_frame = 0
            self.animation_frame_update = 0


class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y, dx, dy, pierces, m, damage, speed):
        super().__init__()
        # spawn at player
        self.x = x
        self.y = y
        self.dx = dx
        self.dy = dy
        self.damage = damage
        self.speed = speed

        self.image = 0
        self.img_change = 0

        self.images = load_spritesheet_images(
            "spr/effects/bullets/normal/all.png",
            24,
            24,
            8,
            8,
            (32, 64)
        )

        for i in range(len(self.images)):
            self.images[i] = pygame.transform.rotate(self.images[i], float(find_angle_with_m(self.dx, self.dy)))

        self.explosion = [pygame.image.load("spr/effects/explosion/01.png"),
                          pygame.image.load("spr/effects/explosion/02.png"),
                          pygame.image.load("spr/effects/explosion/03.png"),
                          pygame.image.load("spr/effects/explosion/04.png"),
                          pygame.image.load("spr/effects/explosion/05.png"),
                          pygame.image.load("spr/effects/explosion/06.png"),
                          pygame.image.load("spr/effects/explosion/07.png"),
                          pygame.image.load("spr/effects/explosion/08.png")]

        self.distance_traveled = 0
        self.max_distance = 500
        self.screen_x = 0
        self.screen_y = 0
        self.hitbox = generate_hitbox(self.images[self.image], self.screen_x, self.screen_y)
        self.m = win

        self.pierces = pierces
        self.hit_enemies = set()

    def move(self):
        # move
        self.x += self.dx * (self.speed / 1.5)
        self.y += self.dy * (self.speed / 1.5)
        self.distance_traveled += (self.dx ** 2 + self.dy ** 2) ** 0.5

        if self.distance_traveled >= self.max_distance:
            if self in player.bullets:
                player.bullets.remove(self)

    def draw(self):
        self.screen_x = self.x - (player.world_x - 250)
        self.screen_y = self.y - (player.world_y - 250)
        win.blit(self.images[self.image], (self.screen_x, self.screen_y))
        self.hitbox = generate_hitbox(self.images[self.image], self.screen_x, self.screen_y)

        if self.image >= len(self.images) - 1:
            self.image = 0

        if self.img_change >= 2:
            self.image += 1
            self.img_change = 0

        self.img_change += 1

    def update(self):
        self.move()
        self.draw()


class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.canmove = False
        self.unlocked_1 = False
        self.unlocked_2 = False
        self.unlocked_3 = False

        """--------Location--------"""
        self.world_x = 250
        self.world_y = 250
        self.screen_x = 250
        self.screen_y = 250

        self.xp = 0
        self.level = 9

        self.sprites = [
            load_spritesheet_images("spr/player.png",128,128,4,4),
            pygame.image.load("spr/bg1.png"),
            pygame.image.load("spr/fireball.png"),
            load_spritesheet_images("spr/player_hurt.png",128,128,4,4)
        ]

        for i in range(len(self.sprites[0])):
            self.sprites[0][i] = pygame.transform.scale(self.sprites[0][i], (64,64))

        for i in range(len(self.sprites[3])):
            self.sprites[3][i] = pygame.transform.scale(self.sprites[3][i], (64,64))

        #self.sprites[0] = pygame.transform.scale(self.sprites[0], (28, 60))
        #self.sprites[3] = pygame.transform.scale(self.sprites[3], (28, 60))
        self.facing = "down"
        self.score = 50
        self.mode = "bg"

        self.speed = 4
        self.hp = 6
        self.iframes = 0
        self.damage = 2

        """ -------Bullet stuff--------"""
        self.multishot = 1 # amount of bullets to be shot
        self.pierces = 1  # amount of pierces -1
        self.bullets = []
        self.maxshotcooldown = 70
        self.bulletcooldown = 0
        self.bulletspeed = 1

        self.gui_base = pygame.image.load("spr/gui/gui.png")
        self.health_part1 = pygame.image.load("spr/gui/health_part_1.png")
        self.health_part2 = pygame.image.load("spr/gui/health_part_2.png")

        self.hitbox = pygame.Rect(self.screen_x - 14, self.screen_y - 30, 28, 60)

    def draw_gui(self):
        self.draw_xp_bar()
        win.blit(self.gui_base, (0, 0))
        if self.hp >= 1:
            win.blit(pygame.image.load("spr/gui/health_part_0_0.png"), (15, 433))
            if self.hp > 1:
                for i in range(self.hp - 1):
                    win.blit(self.health_part2, (76 + (i * 30), 448))

    def draw(self):
        if self.mode == "bg":
            bg_x = -(self.world_x - 250)
            bg_y = -(self.world_y - 250)
            win.blit(self.sprites[1], (bg_x, bg_y))

        if self.iframes % 2 == 0 and self.iframes > 0:
            if self.facing == "down":
                win.blit(self.sprites[3][3], (self.screen_x - 14, self.screen_y - 30))
                self.hitbox = generate_hitbox(self.sprites[0][3], self.screen_x - 14, self.screen_y - 30)
            elif self.facing == "left":
                win.blit(self.sprites[3][1], (self.screen_x - 14, self.screen_y - 30))
                self.hitbox = generate_hitbox(self.sprites[0][1], self.screen_x - 14, self.screen_y - 30)
            elif self.facing == "right":
                win.blit(self.sprites[3][0], (self.screen_x - 14, self.screen_y - 30))
                self.hitbox = generate_hitbox(self.sprites[0][0], self.screen_x - 14, self.screen_y - 30)
            elif self.facing == "up":
                win.blit(self.sprites[3][2], (self.screen_x - 14, self.screen_y - 30))
                self.hitbox = generate_hitbox(self.sprites[0][2], self.screen_x - 14, self.screen_y - 30)
            else:
                self.facing = "down"

        else:
            if self.facing == "down":
                win.blit(self.sprites[0][3], (self.screen_x - 14, self.screen_y - 30))
                self.hitbox = generate_hitbox(self.sprites[0][3], self.screen_x - 14, self.screen_y - 30)
            elif self.facing == "left":
                win.blit(self.sprites[0][1], (self.screen_x - 14, self.screen_y - 30))
                self.hitbox = generate_hitbox(self.sprites[0][1], self.screen_x - 14, self.screen_y - 30)
            elif self.facing == "right":
                win.blit(self.sprites[0][0], (self.screen_x - 14, self.screen_y - 30))
                self.hitbox = generate_hitbox(self.sprites[0][0], self.screen_x - 14, self.screen_y - 30)
            elif self.facing == "up":
                win.blit(self.sprites[0][2], (self.screen_x - 14, self.screen_y - 30))
                self.hitbox = generate_hitbox(self.sprites[0][2], self.screen_x - 14, self.screen_y - 30)
            else:
                self.facing = "down"

        if self.iframes > 0:
            self.iframes -= 1



    def draw_xp_bar(self):

        if self.xp >= self.level * 3:
            self.xp = 0
            self.level += 1
        pygame.draw.rect(win, (0, 0, 255), (28, 393, (self.xp / (self.level * 2)) * 152, 30))
        if self.xp / (self.level * 2) == 1:
            global gamestate
            gamestate = "levelupmenuopen"

    def shoot(self):
        if self.bulletcooldown <= 0:
            self.bulletcooldown = self.maxshotcooldown
            mousepos = pygame.mouse.get_pos()


            base_dx = mousepos[0] - 250
            base_dy = mousepos[1] - 250
            length = (base_dx ** 2 + base_dy ** 2) ** 0.5

            if length == 0:
                return


            base_dx = base_dx / length
            base_dy = base_dy / length


            import math
            base_angle = math.atan2(base_dy, base_dx)


            if self.multishot == 1:

                angles = [base_angle]
            else:

                max_spread = math.pi / 4
                angle_step = max_spread / (self.multishot - 1) if self.multishot > 1 else 0


                angles = []
                for i in range(self.multishot):
                    if self.multishot == 1:
                        angle_offset = 0
                    else:

                        angle_offset = -max_spread / 2 + (i * angle_step)

                    angles.append(base_angle + angle_offset)


            speed = 5
            for angle in angles:
                dx = math.cos(angle) * speed
                dy = math.sin(angle) * speed

                if dx != 0:
                    m = dy / dx
                else:
                    m = float('inf')

                # spawn bulelt at player
                self.bullets.append(Bullet(self.world_x, self.world_y, dx, dy, self.pierces, m * -1,
                                           damage=self.damage, speed=self.bulletspeed))

    def move(self):
        pressed = pygame.key.get_pressed()

        if self.canmove:
            # move player
            if pressed[pygame.K_a]:
                self.world_x -= self.speed
                self.facing = "left"
            if pressed[pygame.K_d]:
                self.world_x += self.speed
                self.facing = "right"
            if pressed[pygame.K_w]:
                self.world_y -= self.speed
                self.facing = "up"
            if pressed[pygame.K_s]:
                self.world_y += self.speed
                self.facing = "down"

        if pressed[pygame.K_SPACE]:
            self.shoot()

    def update(self):
        self.move()
        self.bulletcooldown -= 1

        self.draw()
        self.draw_gui()

        # bullet updation
        for bullet in self.bullets:
            bullet.update()
        if self.iframes == 0:
            for Enemy in enemies:
                if pygame.Rect.colliderect(self.hitbox, Enemy.hitbox):
                    self.hp -= 1
                    self.iframes = 100


def start():
    global gamestate
    gamestate = "game"

    # create player
    global player
    player = Player()
    player.canmove = True

    # create enemies
    global enemies
    enemies = [
        Enemy(random.randrange(0, 12752), random.randrange(0, 9600), 1, 10),
        Enemy(random.randrange(0, 12752), random.randrange(0, 9600), 1, 10),
        Enemy(random.randrange(0, 12752), random.randrange(0, 9600), 1, 10),
        Enemy(random.randrange(0, 12752), random.randrange(0, 9600), 1, 10),
        Enemy(random.randrange(0, 12752), random.randrange(0, 9600), 1, 10),
        Enemy(random.randrange(0, 12752), random.randrange(0, 9600), 1, 10),
        Enemy(random.randrange(0, 12752), random.randrange(0, 9600), 1, 10),
        Enemy(random.randrange(0, 12752), random.randrange(0, 9600), 1, 10),
        Enemy(random.randrange(0, 12752), random.randrange(0, 9600), 1, 10),
        Enemy(random.randrange(0, 12752), random.randrange(0, 9600), 1, 10),
        Enemy(random.randrange(0, 12752), random.randrange(0, 9600), 1, 10),
        Enemy(random.randrange(0, 12752), random.randrange(0, 9600), 1, 10),
        Enemy(random.randrange(0, 12752), random.randrange(0, 9600), 1, 10),
        Enemy(random.randrange(0, 12752), random.randrange(0, 9600), 1, 10),
    ]


global clickableobject


class clickableobject():
    def __init__(self, x, y, spr, hoverimg, which, upgrade=None):
        self.x = x
        self.y = y
        self.spr = spr
        self.hoverimg = hoverimg
        self.which = which
        self.hitbox = generate_hitbox(self.spr, self.x, self.y)
        self.upgrade = upgrade


    def update(self):
        self.hitbox = generate_hitbox(self.spr, self.x, self.y)

        if self.hitbox.collidepoint(mousex, mousey):
            win.blit(self.hoverimg, (self.x, self.y))

            if mousestate[0] and self.hitbox.collidepoint(mousex, mousey):
                if self.which == 0:
                    print("click!")
                    start()

                if self.which == 1:

                    if self.upgrade == 0:
                        player.bulletspeed += 1

                    if self.upgrade == 1:
                        player.hp += 1

                    if self.upgrade == 2:
                        player.multishot += 1


                    if self.upgrade == 3:
                        player.pierces += 1


                    if self.upgrade == 4:
                        player.speed += 1

                    if self.upgrade == 5:
                        player.damage += 1


                    if self.upgrade == 6:
                        player.unlocked_1 = True

                    if self.upgrade == 7:
                        player.unlocked_2 = True

                    if self.upgrade == 8:
                        player.unlocked_3 = True
                    global gamestate
                    gamestate = "game"



        else:
            win.blit(self.spr, (self.x, self.y))


class mouse():
    def __init__(self):
        global mousex, mousey
        global mousestate

        mousex, mousey = pygame.mouse.get_pos()
        mousestate = pygame.mouse.get_pressed()

    def update(self):
        global mousex, mousey
        global mousestate

        mousex, mousey = pygame.mouse.get_pos()

        mousestate = pygame.mouse.get_pressed()


class menu():
    def __init__(self, which, unlocked_1 = None, unlocked_2 = None, unlocked_3 = None):
        self.which = which
        self.buttons = []
        self.unlocked_1 = False
        self.unlocked_2 = False
        self.unlocked_3 = False
        self.unlocked_1 = unlocked_1
        self.unlocked_2 = unlocked_2
        self.unlocked_3 = unlocked_3

        self.startmenuspr = [
            pygame.image.load("spr/gui/startingscreen/base.png"),
            pygame.image.load("spr/gui/startingscreen/start_game_unselected.png"),
            pygame.image.load("spr/gui/startingscreen/start_game_selected.png"),
            pygame.image.load("spr/bg1.png")
        ]

        self.upgrades = [
            pygame.image.load("spr/gui/levelupmenu/arrow_speed.png"),
            pygame.image.load("spr/gui/levelupmenu/health.png"),
            pygame.image.load("spr/gui/levelupmenu/multishot.png"),
            pygame.image.load("spr/gui/levelupmenu/piercing.png"),
            pygame.image.load("spr/gui/levelupmenu/speed.png"),
            pygame.image.load("spr/gui/levelupmenu/strength.png"),
            pygame.image.load("spr/gui/levelupmenu/unlock_slot_1.png"),
            pygame.image.load("spr/gui/levelupmenu/unlock_slot_2.png"),
            pygame.image.load("spr/gui/levelupmenu/unlock_slot_3.png"),
            #pygame.image.load("spr/gui/levelupmenu/poison.png"),
            #pygame.image.load("spr/gui/levelupmenu/fire.png"),
            #pygame.image.load("spr/gui/levelupmenu/water.png")
        ]

        self.upgrade_menu_spr = [
            pygame.image.load("spr/gui/levelupmenu/base.png"),
            pygame.image.load("spr/gui/levelupmenu/locked_1.png"),
            pygame.image.load("spr/gui/levelupmenu/locked_2.png"),
            pygame.image.load("spr/gui/levelupmenu/locked_3.png"),
            pygame.image.load("spr/gui/levelupmenu/locked_1_selected.png"),
            pygame.image.load("spr/gui/levelupmenu/locked_2_selected.png"),
            pygame.image.load("spr/gui/levelupmenu/locked_3_selected.png"),

            self.upgrades
        ]

        self.selected_upgrades = [
            pygame.image.load("spr/gui/levelupmenu/arrow_speed_selected.png"),
            pygame.image.load("spr/gui/levelupmenu/health_selected.png"),
            pygame.image.load("spr/gui/levelupmenu/multishot_selected.png"),
            pygame.image.load("spr/gui/levelupmenu/piercing_selected.png"),
            pygame.image.load("spr/gui/levelupmenu/speed_selected.png"),
            pygame.image.load("spr/gui/levelupmenu/strength_selected.png"),
            pygame.image.load("spr/gui/levelupmenu/unlock_slot_1_selected.png"),
            pygame.image.load("spr/gui/levelupmenu/unlock_slot_2_selected.png"),
            pygame.image.load("spr/gui/levelupmenu/unlock_slot_3_selected.png"),
            #pygame.image.load("spr/gui/levelupmenu/poison_selected.png"),
            #pygame.image.load("spr/gui/levelupmenu/fire_selected.png"),
            #pygame.image.load("spr/gui/levelupmenu/water_selected.png"),

        ]

        if self.which == 0:
            self.buttons = [
                clickableobject(float((500 / 7)) + 101, float(100 + 53),
                                pygame.image.load("spr/gui/startingscreen/start_game_unselected.png"),
                                pygame.image.load("spr/gui/startingscreen/start_game_selected.png"), self.which)
            ]

        if self.which == 1:
            self.upgrades_in_menu = []

            # Create a copy to avoid modifying the original
            available_upgrades = self.upgrades.copy()

            # Remove upgrades based on conditions (in reverse order to avoid index issues)
            if self.unlocked_3:
                available_upgrades.pop(8)
            if self.unlocked_2:
                available_upgrades.pop(7)
            if self.unlocked_1:
                available_upgrades.pop(6)

            if not self.unlocked_1:

                if len(available_upgrades) > 7 and available_upgrades[7] == self.upgrades[7]:
                    available_upgrades.pop(7)

                if len(available_upgrades) > 7 and available_upgrades[7] == self.upgrades[8]:
                    available_upgrades.pop(7)

                elif len(available_upgrades) > 6 and available_upgrades[6] == self.upgrades[8]:
                    available_upgrades.pop(6)

            elif not self.unlocked_2:

                if len(available_upgrades) > 6 and available_upgrades[6] == self.upgrades[8]:
                    available_upgrades.pop(6)
                elif len(available_upgrades) > 7 and available_upgrades[7] == self.upgrades[8]:
                    available_upgrades.pop(7)

            if player.hp >= 6:
                available_upgrades.pop(1)

            if len(available_upgrades) >= 3:
                self.upgrades_in_menu = random.sample(available_upgrades, 3)
            else:
                self.upgrades_in_menu = available_upgrades.copy()

            def get_upgrade_index(upgrade_surface):
                try:
                    index = self.upgrades.index(upgrade_surface)
                    return index
                except ValueError:
                    if upgrade_surface == self.upgrade_menu_spr[1]:
                        return 9
                    elif upgrade_surface == self.upgrade_menu_spr[2]:
                        return 10
                    elif upgrade_surface == self.upgrade_menu_spr[3]:
                        return 11
                    else:
                        print("Upgrade not found, defaulting to 0")
                        return 0

                # Create the main 3 upgrade buttons first

            for i in range(min(3, len(self.upgrades_in_menu))):
                x_pos = (500 / 7) + 30 + (i * 126) if i < 2 else (500 / 7) + 279
                upgrade = self.upgrades_in_menu[i]
                upgrade_index = get_upgrade_index(upgrade)

                self.buttons.append(clickableobject(x_pos, 158, upgrade,
                                                    self.selected_upgrades[upgrade_index],
                                                    self.which, upgrade_index))

                # Handle slot upgrades
            if self.unlocked_1:
                if available_upgrades:
                    slot_upgrade = random.choice(available_upgrades)
                    upgrade_index = get_upgrade_index(slot_upgrade)
                    self.buttons.append(clickableobject((500 / 7) + 30, 258, slot_upgrade,
                                                        self.selected_upgrades[upgrade_index],
                                                        self.which, upgrade_index))
            else:
                self.buttons.append(clickableobject((500 / 7) + 30, 258, self.upgrade_menu_spr[1],
                                                    self.upgrade_menu_spr[4], self.which))

            if self.unlocked_2:
                if available_upgrades:
                    slot_upgrade = random.choice(available_upgrades)
                    upgrade_index = get_upgrade_index(slot_upgrade)
                    self.buttons.append(clickableobject((500 / 7) + 156, 258, slot_upgrade,
                                                        self.selected_upgrades[upgrade_index],
                                                        self.which, upgrade_index))
            else:
                self.buttons.append(clickableobject((500 / 7) + 156, 258, self.upgrade_menu_spr[2],
                                                    self.upgrade_menu_spr[5], self.which))

            if self.unlocked_3:
                if available_upgrades:
                    slot_upgrade = random.choice(available_upgrades)
                    upgrade_index = get_upgrade_index(slot_upgrade)
                    self.buttons.append(clickableobject((500 / 7) + 279, 258, slot_upgrade,
                                                        self.selected_upgrades[upgrade_index],
                                                        self.which, upgrade_index))
            else:
                self.buttons.append(clickableobject((500 / 7) + 279, 258, self.upgrade_menu_spr[3],
                                                    self.upgrade_menu_spr[6], self.which))

    def start_menu(self):
        win.blit(self.startmenuspr[3], (0, 0))
        win.blit(self.startmenuspr[0], (500 / 7, 100))

    def upgrade_menu(self):
        win.blit(self.upgrade_menu_spr[0], (500 / 7, 100))

    def update(self):
        if self.which == 0:
            self.start_menu()

        if self.which == 1:
            self.upgrade_menu()

        if len(self.buttons) > 0:
            for clickableobject in self.buttons:
                clickableobject.update()

        pygame.display.update()


startmenu = menu(0)
mouse = mouse()


def update():
    win.fill((0, 0, 0))
    player.update()

    enemies_to_remove = []

    for enemy in enemies:
        enemy.update()

        if enemy.hp <= 0 and enemy.animation_frame >= 7:
            enemies_to_remove.append(enemy)
            continue

        for bullet in player.bullets[:]:
            if enemy.hitbox.colliderect(bullet.hitbox) and enemy not in bullet.hit_enemies:
                bullet.pierces -= 1
                if bullet.pierces <= 0:
                    enemy.take_damage(bullet.damage)
                    if bullet in player.bullets:
                        player.bullets.remove(bullet)
                else:
                    enemy.take_damage(bullet.damage)

                bullet.hit_enemies.add(enemy)

    for enemy in enemies_to_remove:
        if enemy in enemies:
            enemies.remove(enemy)
            
            i = random.randrange(1,5)
            if i == 1:
                enemies.append(Enemy(random.randrange(0, 12752), random.randrange(0, 9600), 1, 10))
            
            enemies.append(Enemy(random.randrange(0, 12752), random.randrange(0, 9600), 1, 10))

            player.score += 10

    pygame.display.set_caption(f"Roguelite score: {player.score}")
    pygame.display.update()


run = True
while run:

    mouse.update()

    if gamestate == "startmenu":
        Player.canmove = False
        startmenu.update()

    elif gamestate == "levelupmenuopen":
        upgrade_menu = menu(1, player.unlocked_1, player.unlocked_2, player.unlocked_3)
        gamestate = "levelupmenu"
        player.xp = 0
        player.level += 1

    elif gamestate == "levelupmenu":
        upgrade_menu.update()
        Player.canmove = False

    elif gamestate == "game":
        Player.canmove = True
        update()

    elif gamestate == "death":
        death_menu = menu(2)
        gamestate = "deathmenu"

    elif gamestate == "deathmenu":
        death_menu.update()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
    clock.tick(60)
pygame.quit()
